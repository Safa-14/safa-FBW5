# Student_management
## First Task was to write a studnet name and add  to him his grades then save all the data down when we click on the button "save button"
## Second Task was to check the existence of the selected course before adding it to the ul liste
## Third task was to save all data on the local storage