window.onload = function () {
    //get HTML elements
    let coursesList = document.querySelector('#coursesList')
    let studentGradeInp = document.querySelector('#studentGradeInp')
    let addGradeBtn = document.querySelector('#addGradeBtn')
    let gradeListElement = document.querySelector('#gradeListElement')

    let gradesArr = []
    addGradeBtn.addEventListener('click',function (e) {
        let selectedCourse = coursesList.options[coursesList.selectedIndex].value
        let grade = studentGradeInp.value
        if (selectedCourse !== '' & grade.trim() !== '') {
            
            let listItem = document.createElement('li')
            listItem.innerText = selectedCourse + ': ' + grade + '%'
            gradeListElement.append(listItem)
            studentGradeInp.value = ''
            
            let gradeObj = {}
            

            gradeObj[selectedCourse.replace(/ /g, '_')] = grade
            gradesArr.push(gradeObj)
            
            
            
        }











            //hatha eli 7abit na3mlou haka 3alech commentitou


            // let gradeObj = {}
            // if (gradesArr.length == 0) {
            //     let listItem = document.createElement('li')
            //     listItem.innerHTML = selectedCourse + ': ' + grade + '%'
            //     gradeListElement.append(listItem)
            //     gradeObj[selectedCourse.replace(/ /g, '_')] = grade
            //     gradesArr.push(gradeObj)
            // }else{
            //     gradesArr.forEach(element => {
            //         let x = JSON.stringify(element)
            //         if (x.indexOf(selectedCourse) == -1) {
            //             console.log(false);
            //             let listItem = document.createElement('li')
            //             listItem.innerHTML = selectedCourse + ': ' + grade + '%'
            //             gradeListElement.append(listItem)
            //             gradeObj[selectedCourse.replace(/ /g, '_')] = grade
            //             gradesArr.push(gradeObj)
            //             console.log();
                    
            //         }else{
            //             alert("Wrong")
            //             let listItem = document.createElement('li')
            //             listItem.innerHTML = ''
            //         }
                
                
            //     });
                
            // }
            // studentGradeInp.value = ''
        
    })


}



